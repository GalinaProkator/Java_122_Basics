
public class FishermanExample {
	public static void main(String[] args) {
		Fisherman fishermanRoy = new Fisherman ("Canada", 32);

	}
}
