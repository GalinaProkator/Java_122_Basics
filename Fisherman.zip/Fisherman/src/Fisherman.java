
public class Fisherman {
	public Fisherman (String place, int lengthOfFish) {
		int realLengthOfFish = lengthOfFish/2;
		System.out.println("I catched in " + place + " a fish " + realLengthOfFish + " inches long!");
	}
}
