
public class Fisherman {
	private String place;
	private int lengthOfFish;
	private int realLengthOfFish;
	
	public Fisherman (String place, int lengthOfFish) {
		this.place = place;
		this.lengthOfFish = lengthOfFish;
		
		this.realLengthOfFish = lengthOfFish/2;
		System.out.println("I catched in " + place + " a fish " + realLengthOfFish + " inches long!");
	}
}
